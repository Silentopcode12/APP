# Chatbot Webapp

Basic Python FastAPI + OpenAI web chatbot with a simple UI.

## Local (venv)

```bash
cd "/Users/shresthpathak/Documents/New project/chatbot-webapp"
python -m venv .venv
source .venv/bin/activate
pip install -r backend/requirements.txt
cp .env.example .env
uvicorn backend.main:app --reload --port 8000
```

Open http://localhost:8000

## Docker Compose

```bash
cd "/Users/shresthpathak/Documents/New project/chatbot-webapp"
cp .env.example .env
# edit .env with your key

docker compose up --build -d
```

Open http://localhost:8000

## EC2 (quick steps)

1. Launch an EC2 instance and allow inbound TCP `8000` from your IP in the security group.
2. SSH into the instance and install Docker + Docker Compose.
3. Copy this project to the instance (e.g., git clone or scp).
4. Create `.env` with your `OPENAI_API_KEY`.
5. Run `docker compose up --build -d`.
6. Visit `http://<EC2_PUBLIC_IP>:8000`.

## Notes

- Keep the OpenAI API key on the server (never in the browser).
- The SDK reads `OPENAI_API_KEY` from environment variables.
